document.addEventListener("DOMContentLoaded", () => {
  const fileInput = document.getElementById("fileInput");
  const dropZone = document.getElementById("dropZone");
  const selectedFiles = document.getElementById("selectedFiles");
  const uploadForm = document.getElementById("uploadForm");

  function showSelected(files) {
    if (!files || !files.length) {
      selectedFiles.textContent = "No files selected";
      return;
    }
    selectedFiles.textContent = files.length === 1 ? files[0].name : `${files.length} files selected`;
  }
  fileInput?.addEventListener("change", () => showSelected(fileInput.files));
  ["dragenter", "dragover"].forEach(eventName => dropZone?.addEventListener(eventName, event => {
    event.preventDefault(); dropZone.classList.add("dragover");
  }));
  ["dragleave", "drop"].forEach(eventName => dropZone?.addEventListener(eventName, event => {
    event.preventDefault(); dropZone.classList.remove("dragover");
  }));
  dropZone?.addEventListener("drop", event => {
    if (event.dataTransfer?.files?.length) {
      fileInput.files = event.dataTransfer.files;
      showSelected(fileInput.files);
    }
  });
  uploadForm?.addEventListener("submit", event => {
    if (!fileInput.files.length) {
      event.preventDefault();
      alert("Choose at least one file before uploading.");
    }
  });

  const searchInput = document.getElementById("searchInput");
  const typeFilter = document.getElementById("typeFilter");
  const sortSelect = document.getElementById("sortSelect");
  const table = document.getElementById("fileTable");
  const visibleCount = document.getElementById("visibleCount");

  function updateRows() {
    const query = (searchInput.value || "").trim().toLowerCase();
    const type = (typeFilter.value || "").toLowerCase();
    const rows = [...table.querySelectorAll("tr.file-row")];
    rows.forEach(row => {
      const matchesQuery = row.dataset.name.includes(query) || row.dataset.path.includes(query);
      const matchesType = !type || row.dataset.type === type;
      row.hidden = !(matchesQuery && matchesType);
    });
    const visible = rows.filter(row => !row.hidden);
    const sort = sortSelect.value;
    visible.sort((a, b) => {
      if (sort === "newest") return Number(b.dataset.modified) - Number(a.dataset.modified);
      if (sort === "oldest") return Number(a.dataset.modified) - Number(b.dataset.modified);
      if (sort === "largest") return Number(b.dataset.size) - Number(a.dataset.size);
      if (sort === "smallest") return Number(a.dataset.size) - Number(b.dataset.size);
      return a.dataset.name.localeCompare(b.dataset.name);
    });
    visible.forEach(row => table.appendChild(row));
    const empty = document.getElementById("emptyRow");
    if (empty) empty.hidden = rows.length > 0;
    let noMatch = document.getElementById("noMatchRow");
    if (!noMatch) {
      noMatch = document.createElement("tr");
      noMatch.id = "noMatchRow";
      noMatch.innerHTML = '<td colspan="6"><div class="empty-state"><div>⌕</div><strong>No matching files</strong><p>Try another search or file type.</p></div></td>';
      table.appendChild(noMatch);
    }
    noMatch.hidden = visible.length > 0 || rows.length === 0;
    visibleCount.textContent = `Showing ${visible.length} of ${rows.length} file(s)`;
  }
  [searchInput, typeFilter, sortSelect].forEach(el => el?.addEventListener("input", updateRows));
  updateRows();

  document.getElementById("themeToggle")?.addEventListener("click", () => {
    document.body.classList.toggle("dark");
    try { localStorage.setItem("smartfile-dark", document.body.classList.contains("dark") ? "yes" : "no"); } catch (_) {}
  });
  try {
    if (localStorage.getItem("smartfile-dark") === "yes") document.body.classList.add("dark");
  } catch (_) {}

  document.getElementById("newFolderBtn")?.addEventListener("click", () => document.getElementById("folderDialog").showModal());
  document.querySelectorAll("[data-close]").forEach(button => button.addEventListener("click", () => document.getElementById(button.dataset.close).close()));
  document.querySelectorAll(".rename-button").forEach(button => button.addEventListener("click", () => {
    document.getElementById("renamePath").value = button.dataset.path;
    document.getElementById("renameName").value = button.dataset.name;
    document.getElementById("renameDialog").showModal();
    document.getElementById("renameName").focus();
    document.getElementById("renameName").select();
  }));

  document.getElementById("duplicateBtn")?.addEventListener("click", async () => {
    const button = document.getElementById("duplicateBtn");
    const resultBox = document.getElementById("duplicateResults");
    resultBox.hidden = false;
    resultBox.textContent = "Scanning file contents…";
    button.disabled = true;
    try {
      const response = await fetch("/api/duplicates");
      if (!response.ok) throw new Error("The duplicate scan could not be completed.");
      const data = await response.json();
      if (!data.groups.length) {
        resultBox.textContent = "✨ No duplicate files found. Your workspace is looking tidy!";
      } else {
        resultBox.replaceChildren();
        const summary = document.createElement("strong");
        summary.textContent = `${data.duplicate_files} duplicate file(s) found`;
        const list = document.createElement("ul");
        data.groups.forEach(group => {
          const item = document.createElement("li");
          item.textContent = group.map(file => file.path).join(" = ");
          list.appendChild(item);
        });
        resultBox.append(summary, list);
      }
    } catch (error) {
      resultBox.textContent = error.message;
    } finally {
      button.disabled = false;
    }
  });

  // Dismiss transient feedback messages after a few seconds.
  document.querySelectorAll(".flash").forEach(message => {
    setTimeout(() => { message.style.transition = "opacity .4s"; message.style.opacity = "0"; }, 4500);
  });
});
