from pathlib import Path
from datetime import datetime
from collections import Counter
import hashlib
import os
import shutil
import zipfile
from io import BytesIO

from flask import Flask, render_template, request, redirect, url_for, flash, send_file, jsonify, abort
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_ROOT = BASE_DIR / "uploads"
UPLOAD_ROOT.mkdir(exist_ok=True)
app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "change-this-secret-key")
MAX_UPLOAD_MB = 100
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024

ALLOWED_NAME_CHARS = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ._-()[]")

def safe_target(relative=""):
    """Resolve a user-supplied relative path and ensure it stays inside uploads/."""
    relative = (relative or "").replace("\\", "/").strip("/")
    target = (UPLOAD_ROOT / relative).resolve()
    if target != UPLOAD_ROOT.resolve() and UPLOAD_ROOT.resolve() not in target.parents:
        abort(400, "Invalid path")
    return target

def relative_name(path):
    return path.relative_to(UPLOAD_ROOT).as_posix()

def file_hash(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

def human_size(size):
    units = ["B", "KB", "MB", "GB", "TB"]
    value = float(size)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024


# File types used by the Smart Organizer.
FILE_CATEGORIES = {
    ".mp3": "MP3", ".wav": "Audio", ".aac": "Audio", ".flac": "Audio", ".ogg": "Audio", ".m4a": "Audio",
    ".mp4": "MP4", ".mkv": "Videos", ".mov": "Videos", ".avi": "Videos", ".webm": "Videos",
    ".pdf": "PDF",
    ".zip": "ZIP", ".rar": "ZIP", ".7z": "ZIP", ".tar": "ZIP", ".gz": "ZIP",
    ".png": "Images", ".jpg": "Images", ".jpeg": "Images", ".gif": "Images", ".webp": "Images", ".svg": "Images", ".bmp": "Images",
    ".doc": "Documents", ".docx": "Documents", ".txt": "Documents", ".rtf": "Documents", ".odt": "Documents",
    ".xls": "Spreadsheets", ".xlsx": "Spreadsheets", ".csv": "Spreadsheets", ".ods": "Spreadsheets",
    ".ppt": "Presentations", ".pptx": "Presentations", ".odp": "Presentations",
    ".py": "Code", ".js": "Code", ".html": "Code", ".css": "Code", ".java": "Code", ".c": "Code", ".cpp": "Code", ".json": "Code",
}
MANAGED_CATEGORIES = set(FILE_CATEGORIES.values()) | {"Other"}

def category_for_file(path):
    return FILE_CATEGORIES.get(path.suffix.lower(), "Other")

def unique_destination(folder, filename):
    destination = folder / filename
    if not destination.exists():
        return destination
    stem, suffix = Path(filename).stem, Path(filename).suffix
    counter = 1
    while (folder / f"{stem}_{counter}{suffix}").exists():
        counter += 1
    return folder / f"{stem}_{counter}{suffix}"

def list_files():
    rows = []
    for path in UPLOAD_ROOT.rglob("*"):
        if path.is_file() and not path.name.startswith("."):
            stat = path.stat()
            rows.append({
                "name": path.name,
                "path": relative_name(path),
                "folder": relative_name(path.parent) if path.parent != UPLOAD_ROOT else "",
                "extension": path.suffix.lower().lstrip(".") or "no extension",
                "size": stat.st_size,
                "size_text": human_size(stat.st_size),
                "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%d %b %Y, %I:%M %p"),
                "modified_ts": stat.st_mtime,
            })
    return rows

def dashboard_stats(rows):
    total_bytes = sum(item["size"] for item in rows)
    types = Counter(item["extension"] for item in rows)
    return {
        "count": len(rows),
        "total_bytes": total_bytes,
        "total_size": human_size(total_bytes),
        "types": [{"name": key, "count": value} for key, value in types.most_common(6)],
    }

@app.get("/")
def index():
    rows = list_files()
    folders = sorted(relative_name(p) for p in UPLOAD_ROOT.rglob("*") if p.is_dir())
    return render_template("index.html", files=rows, stats=dashboard_stats(rows), folders=folders)

@app.post("/upload")
def upload():
    target_folder = request.form.get("folder", "").strip()
    target = safe_target(target_folder)
    target.mkdir(parents=True, exist_ok=True)
    incoming = request.files.getlist("files")
    saved = 0
    for item in incoming:
        if not item or not item.filename:
            continue
        filename = secure_filename(item.filename)
        if not filename:
            continue
        destination = target / filename
        if destination.exists():
            stem, suffix = destination.stem, destination.suffix
            counter = 1
            while (target / f"{stem}_{counter}{suffix}").exists():
                counter += 1
            destination = target / f"{stem}_{counter}{suffix}"
        item.save(destination)
        saved += 1
    flash(f"Uploaded {saved} file(s).", "success" if saved else "info")
    return redirect(url_for("index"))

@app.post("/organize")
def organize_files():
    """Move files into extension-based category folders without overwriting files."""
    moved = skipped = errors = 0
    candidates = [p for p in UPLOAD_ROOT.rglob("*") if p.is_file() and not p.name.startswith(".")]
    for source in candidates:
        try:
            relative_parent = source.parent.relative_to(UPLOAD_ROOT)
            # Avoid repeatedly organizing files already in a top-level category folder.
            if len(relative_parent.parts) == 1 and relative_parent.parts[0] in MANAGED_CATEGORIES:
                skipped += 1
                continue
            category = category_for_file(source)
            destination_folder = UPLOAD_ROOT / category
            destination_folder.mkdir(parents=True, exist_ok=True)
            destination = unique_destination(destination_folder, source.name)
            if source.resolve() == destination.resolve():
                skipped += 1
                continue
            shutil.move(str(source), str(destination))
            moved += 1
        except (OSError, ValueError):
            errors += 1
    if moved:
        message = f"Organized {moved} file(s) into type-based folders."
        if skipped:
            message += f" Skipped {skipped} file(s) already organized."
        if errors:
            message += f" {errors} file(s) could not be moved."
        flash(message, "success" if not errors else "info")
    elif errors:
        flash(f"No files were organized; {errors} file(s) could not be moved.", "error")
    else:
        flash("No files needed organizing. Upload files to get started.", "info")
    return redirect(url_for("index"))


@app.post("/folder")
def create_folder():
    name = request.form.get("name", "").strip()
    parent = request.form.get("parent", "").strip()
    if not name or name in {".", ".."} or any(c not in ALLOWED_NAME_CHARS for c in name):
        flash("Use a folder name with letters, numbers, spaces, dots, underscores, or hyphens.", "error")
        return redirect(url_for("index"))
    destination = safe_target(parent) / name
    if destination.exists():
        flash("That folder already exists.", "error")
    else:
        destination.mkdir(parents=True, exist_ok=True)
        flash(f"Folder '{name}' created.", "success")
    return redirect(url_for("index"))

@app.post("/rename")
def rename():
    old = request.form.get("path", "")
    new_name = request.form.get("new_name", "").strip()
    source = safe_target(old)
    if not source.is_file():
        abort(404)
    if not new_name or new_name in {".", ".."} or "/" in new_name or "\\" in new_name:
        flash("Enter a valid file name without folder separators.", "error")
    elif any(c not in ALLOWED_NAME_CHARS for c in new_name):
        flash("File name contains unsupported characters.", "error")
    else:
        destination = source.with_name(new_name)
        if destination.exists():
            flash("A file with that name already exists.", "error")
        else:
            source.rename(destination)
            flash("File renamed successfully.", "success")
    return redirect(url_for("index"))

@app.post("/delete")
def delete():
    path = safe_target(request.form.get("path", ""))
    if path.is_file():
        path.unlink()
        flash("File deleted.", "success")
    else:
        flash("File not found.", "error")
    return redirect(url_for("index"))

@app.get("/download/<path:relative>")
def download(relative):
    path = safe_target(relative)
    if not path.is_file():
        abort(404)
    return send_file(path, as_attachment=True, download_name=path.name)

@app.get("/zip")
def download_zip():
    memory_file = BytesIO()
    with zipfile.ZipFile(memory_file, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in UPLOAD_ROOT.rglob("*"):
            if path.is_file() and path.name != "smart_file_manager.zip":
                archive.write(path, arcname=relative_name(path))
    memory_file.seek(0)
    return send_file(memory_file, mimetype="application/zip", as_attachment=True, download_name="smart_file_manager.zip")

@app.get("/api/duplicates")
def duplicates():
    groups = {}
    for item in list_files():
        path = safe_target(item["path"])
        digest = file_hash(path)
        groups.setdefault(digest, []).append(item)
    results = [group for group in groups.values() if len(group) > 1]
    return jsonify({"groups": results, "duplicate_files": sum(len(group) - 1 for group in results)})

@app.get("/api/stats")
def stats_api():
    rows = list_files()
    return jsonify(dashboard_stats(rows))

@app.errorhandler(413)
def too_large(_error):
    flash(f"Upload exceeds the {MAX_UPLOAD_MB} MB request limit.", "error")
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
