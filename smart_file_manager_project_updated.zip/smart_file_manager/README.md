# SmartFile — Smart File Manager

A student-friendly final-year project built with **HTML, CSS, JavaScript, Python, and Flask**. It runs locally and stores files in the project's `uploads/` folder.

## Features
- Responsive dashboard with file count, storage used, and file categories
- Multi-file upload and drag-and-drop upload area
- Search by filename or path, file-type filtering, and sorting
- Create folders and upload files into a selected folder
- Rename, download, and delete files
- Automatic extension-based organization into MP3, MP4, PDF, ZIP, Images, Documents, Audio, Videos, Spreadsheets, Presentations, Code, and Other folders
- Duplicate finder based on SHA-256 file hashes (compares content, not names)
- Export the complete workspace as a ZIP file
- Dark mode toggle
- Local-first storage: uploaded files remain on your computer

## Requirements
- Python 3.10 or newer
- pip

## Run on Windows
1. Extract the ZIP file.
2. Open Command Prompt or the VS Code terminal in the `smart_file_manager` folder.
3. Create a virtual environment (recommended):
   ```bat
   python -m venv venv
   venv\Scripts\activate
   ```
4. Install packages:
   ```bat
   pip install -r requirements.txt
   ```
5. Start the website:
   ```bat
   python app.py
   ```
6. Open `http://127.0.0.1:5000` in your browser.

## Project structure
```text
smart_file_manager/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
├── static/
│   ├── css/style.css
│   └── js/app.js
└── uploads/
```

## How to demonstrate it
1. Upload a few files.
2. Upload the same file twice under different names to test Duplicate Finder.
3. Search for a filename and use the type filter and sort menu.
4. Create a folder and upload a file into it.
5. Click **Organize files** in Smart tools to sort files into category folders.
6. Rename and download a file.
6. Export the workspace ZIP.
7. Switch to dark mode.

## Important notes
- This is a local educational prototype, not a production cloud-storage service.
- Do not expose the Flask development server to the public internet. For deployment, add authentication, CSRF protection, stronger authorization, malware scanning, rate limits, and production hosting.
- The Flask development server runs with debug mode enabled in this student version. Turn debug off before any deployment.
- Files are stored on disk in `uploads/`. Back up or clear that folder only when you intend to remove the uploaded demo files.
- The default secret key is for local development only. Set `FLASK_SECRET_KEY` to a strong random value for anything beyond a local demo.
